# -*- coding: utf-8 -*-
"""
Created on Wed Feb  2 08:58:57 2022

@author: Giovanni
"""


import pandas as pd
import numpy as np


import os # per parlare CON IL SISTEMA OPERATIVO
# 3 righe per posizionarci automaticamente 
# nella stessa directory del file che tiamo
# editando
abspath = os.path.abspath("2022_02_02.py") # percorso assoluto di questo script
dname = os.path.dirname(abspath) # directoy di questo script
os.chdir(dname) # la directory di lavoro è adesso la stessa dello script
####